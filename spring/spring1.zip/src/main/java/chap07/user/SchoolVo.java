package chap07.user;

public class SchoolVo {
	private int schoolno;
	private int userno;
	private String school;
	private String year;
	
	public int getSchoolno() {
		return schoolno;
	}
	public void setSchoolno(int schoolno) {
		this.schoolno = schoolno;
	}
	public int getUserno() {
		return userno;
	}
	public void setUserno(int userno) {
		this.userno = userno;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
}
